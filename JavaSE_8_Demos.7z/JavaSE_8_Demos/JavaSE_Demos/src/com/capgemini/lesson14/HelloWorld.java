package com.capgemini.lesson14;


public class HelloWorld 
{
   public String say() 
   { 
      return("HelloWorld!"); 
    }
 } 

